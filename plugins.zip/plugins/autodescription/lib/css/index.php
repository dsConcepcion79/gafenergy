<?php
/**
 * Childhood means simplicity. Look at the world with the child's eye - it is very beautiful.
 *
 * - Kailash Satyarthi, <https://www.facebook.com/KailashSatyarthi/posts/674380652662460:0>
 */
