<?php
/**
 * Ich konnte kein vernünftiges Wort mit jemandem sprechen.
 *
 * (I couldn't speak one sensible word with anyone.)
 *
 * - Gustav Mahler
 */
