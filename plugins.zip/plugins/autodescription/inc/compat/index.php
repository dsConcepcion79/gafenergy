<?php
/**
 * Where every something, being blent together,
 * Turns to a wild of nothing, save of joy,
 * Express’d and not express’d. But when this ring
 * Parts from this finger, then parts life from hence:
 * O! then be bold to say Bassanio’s dead.
 *
 * - William Shakespeare, The Merchant of Venice
 */
