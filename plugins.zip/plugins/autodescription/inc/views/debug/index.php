<?php
/**
 * We often discover what will do, by finding out what will not do;
 * and probably he who never made a mistake never made a discovery.
 *
 * - Samuel Smiles
 */
