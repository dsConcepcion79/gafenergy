<?php
/**
 * Las cadenas que más nos encadenan son las cadenas que hemos roto.
 *
 * (The chains that chain us the most are the chains that we have broken.)
 *
 * - Antonio Porchia
 */
