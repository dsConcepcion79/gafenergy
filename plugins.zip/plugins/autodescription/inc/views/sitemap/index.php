<?php
/**
 * Man cannot discover new oceans, unless he has the courage to lose sight of the shore.
 *
 * - Andre Gide
 */
