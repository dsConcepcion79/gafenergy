<?php
/**
 * Well-lit streets discourage sin, but don't overdo it.
 *
 * - William J. Kennedy
 */
