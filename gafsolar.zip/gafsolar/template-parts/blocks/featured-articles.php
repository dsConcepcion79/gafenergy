<?php

/**
 * Featured Articles Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'articles-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'articles';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
// None for this block so far...

?>
<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?> bg-ltblue v45 m-v45-20">

  <div class="container">
    <div class="row">
      <div class="col-sm-8 col-md-6 h-r30">
        <hr class="chunky chunkyintext blue" />
        <h2>Featured Articles</h2>
      </div>
    </div>

    <div class="row">

      <?php
        $post_objects = get_field('post_objects');
        if( $post_objects ):
        foreach( $post_objects as $post): // variable must be called $post (IMPORTANT)
        setup_postdata($post);
      ?>
        <div class="col-sm-6">
          <article>
           <?php /* <header class="article-meta">
              Posted <time datetime="<?php the_time('Y-m-d'); ?>"><?php the_time('F j, Y'); ?></time>
            </header> */ ?>
            <h3>
              <a href="<?php the_permalink(); ?>">
                <?php the_title(); ?>
              </a>
            </h3>
            <a href="<?php the_permalink(); ?>" class="btn btn-primary">Read More</a>
          </article>
        </div>
    <?php
      endforeach;
      wp_reset_postdata();
      else:

      $args = array(
      'posts_per_page' => 2,
      'post_type' => 'post'
      );
      $the_query = new WP_Query( $args );
      if( $the_query->have_posts() ):
      while ( $the_query->have_posts() ) : $the_query->the_post();
    ?>
    <div class="col-sm-6">
      <article>
        <?php /* <header class="article-meta">
          Posted <time datetime="<?php the_time('Y-m-d'); ?>"><?php the_time('F j, Y'); ?></time>
        </header> */ ?>
        <h3>
          <a href="<?php the_permalink(); ?>">
            <?php the_title(); ?>
          </a>
        </h3>
        <a href="<?php the_permalink(); ?>" class="btn btn-primary" title="Read more about <?php the_title(); ?>">Read More</a>
      </article>
    </div>
    <?php
      endwhile;
      endif;

      wp_reset_postdata();
      endif;
    ?>
    </div>
  </div>
</section>
