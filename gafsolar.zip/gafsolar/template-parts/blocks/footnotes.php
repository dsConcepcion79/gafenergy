<?php

/**
 * Footnotes Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'footnotes-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'footnotes';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
//$headinglevel = get_field('heading_level');
//$heading = get_field('heading');

if( have_rows('footnotes') ):
  $footcount=0;
?>

<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?>">
  <div class="container">
    <div class="footnotes-inner">
      <h2 class="visually-hidden" id="footnote-label">Footnotes</h2>
      <ol>
        <?php
          while ( have_rows('footnotes') ) : the_row();
          $footcount++;
        ?>
          <li id="f<?php echo $footcount; ?>">
            <?php the_sub_field('footnote'); ?>
            <a href="#f<?php echo $footcount; ?>-ref" aria-label="Back to content">↩</a>
          </li>
        <?php endwhile; ?>
      </ol>
    </div>
  </div>
</section>

<?php endif; ?>
