<?php

/**
 * Text Image Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'text-image-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'text-image';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
$barcolor = get_field('bar_color');
// $bartop = get_field('bar_above_both_columns');
$imageposition = get_field('image_position');
$image = get_field('image') ?: 295;
$imagelink = get_field('image_link');
$video = get_field('video');
$videoaspect = get_field('video_aspect_ratio');
$heading = get_field('heading');
$text = get_field('text');
$buttonlink = get_field('button_link');
$buttontext = get_field('button_text');
$buttoncolor = get_field('button_color');

?>
<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); if ($barcolor) { echo ' v75 m-v45-75'; } ?>">
  <?php if ($barcolor) { ?>
    <div class="container">
  <?php } else { ?>
    <div class="container v60">
  <?php } ?>
    <div class="row">
      <?php if ($barcolor) { ?>
        <div class="<?php /* col-sm-8 */ ?>col-md-6 col-xl-5 m-v0-60 <?php if ($imageposition == 'Image on Left') { echo 'order-md-12 h-l30'; } else { echo 'h-r30'; } ?>">
          <hr class="chunky  chunkyintext <?php if ($barcolor == 'Blue') { echo 'blue'; } else { echo 'red'; } if ($imageposition == 'Image on Left') { echo ' chunky-right'; } ?>" />
          <h2><?php echo $heading; ?></h2>
      <?php } else { ?>
        <div class="<?php /* col-sm-8 */ ?>col-md-6 col-xl-5 v75 m-v0-75 md-v0 lg-v0 <?php if ($imageposition == 'Image on Left') { echo 'order-md-12 h-l30'; } else { echo 'h-r30'; } ?>">
        <h2 class="smaller"><?php echo $heading; ?></h2>
      <?php } ?>
        <?php if ($text) { ?>
          <?php echo $text; ?>
        <?php } ?>
        <?php if ($buttonlink) { ?>
          <div class="button-row">
            <a href="<?php echo $buttonlink; ?>" class="btn <?php if ($buttoncolor == 'Red') { echo 'btn-secondary'; } else { echo 'btn-primary'; } ?>">
              <?php if ($buttontext) { echo $buttontext; } else { echo 'View Details'; } ?>
            </a>
          </div>
        <?php } ?>
      </div>
      <div class="<?php /* col-sm-4 */ ?>col-md-6 col-xl-7 <?php if ($imageposition == 'Image on Left') { echo 'order-md-1'; } ?>">
        <?php if ($video) { ?>
          <div class="embed-responsive embed-responsive-<?php if ($videoaspect == '4 by 3') { echo '4by3'; } elseif ($videoaspect == '16 by 9') { echo '16by9'; } elseif ($videoaspect == '21 by 9') { echo '21by9'; } elseif ($videoaspect == '1 by 1') { echo '1by1'; } ?>">
            <?php echo $video; ?>
          </div>
        <?php } else { ?>
          <div class="image-wrapper">
            <?php if ($imagelink) { ?>
              <a href="<?php echo $imagelink; ?>">
                <?php echo wp_get_attachment_image( $image, 'column-image' ); ?>
              </a>
            <?php } else { ?>
              <?php echo wp_get_attachment_image( $image, 'column-image' ); ?>
            <?php } ?>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
</section>
