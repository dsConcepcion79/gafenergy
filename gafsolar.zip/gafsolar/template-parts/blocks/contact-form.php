<?php

/**
 * Contact Form Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'contact-form' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'contact';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
$topmargin = get_field('top_margin');
$image = get_field('image') ?: 295;
// $heading = get_field('heading') ?: 'Your heading here...';
$contactform = get_field('contact_form');
$smallprint = get_field('small_print');
?>
<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?>">
  <div class="container <?php if ($topmargin) { echo 'v75'; } else { echo 'v0-75'; } ?>">
    <div class="row">
      <div class="<?php /* col-sm-3 */ ?>col-md-6 col-xl-7 m-v0-40">
        <div class="image-wrapper">
          <?php echo wp_get_attachment_image( $image, 'column-image' ); ?>
        </div>
      </div>
      <div class="<?php /* col-sm-9 */ ?>col-md-6 col-xl-5 m-h30">
        <?php /* <h2><?php echo $heading; ?></h2> */ ?>
        <?php echo $contactform; ?>
        <?php if ($smallprint) { ?>
          <p><small><?php echo $smallprint; ?></small></p>
        <?php } ?>
      </div>
    </div>
  </div>
</section>
