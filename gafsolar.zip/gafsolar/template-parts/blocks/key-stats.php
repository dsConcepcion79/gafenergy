<?php

/**
 * Key Statistics Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'key-stats-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'key-stats';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
$backgroundcolor = get_field('background_color');

if( have_rows('statistics') ):
?>

<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?> antialiased" style="background-color:<?php echo $backgroundcolor; ?>">
  <div class="container">
    <div class="row">
      <?php
        while ( have_rows('statistics') ) : the_row();
        $icon = get_sub_field('icon');
        $text = get_sub_field('text');
      ?>
        <div class="col-sm key-stat-wrapper">
          <div class="key-stat">
            <?php if ($icon) { ?>
              <div class="key-stat-image">
                <img src="<?php bloginfo('template_directory'); ?>/img/x.gif" data-src="<?php echo $icon['url']; ?>" class="lazy" alt="<?php echo $icon['alt']; ?>" />
              </div>
            <?php } ?>
            <?php echo $text; ?>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<?php endif; ?>
