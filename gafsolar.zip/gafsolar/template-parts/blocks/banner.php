<?php

/**
 * Banner Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'banner-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'banner';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
$bannerwidth = get_field('banner_width');
$image = get_field('image') ?: 295;
if ($bannerwidth == 'Full Width') {
  $imagedata = wp_get_attachment_image_src( $image, "banner-full" );
} else {
  $imagedata = wp_get_attachment_image_src( $image, "banner" );
}
//$imagewidth = $image['width'];
//$imageheight = $image['height'];
$bannerpadding = $imagedata[2] / $imagedata[1] * 100;

$captionalignment = get_field('copy_block_position');
$heading = get_field('heading');
$text = get_field('text');
$buttonlink = get_field('button_link');
$buttontext = get_field('button_text');
$hasstatistics = get_field('has_statistics');

?>
<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); if ($bannerwidth == 'Full Width') { echo ' banner-full'; } if ($hasstatistics) { echo ' banner-statistics'; } ?>">
  <div class="banner-wrapper">
    <div class="banner-inner sized-image" style="padding-bottom:<?php echo $bannerpadding; ?>%">
      <?php  ?>
      <?php
        if ($bannerwidth == 'Full Width') {
          echo wp_get_attachment_image( $image, 'banner-full' );
        } else {
          echo wp_get_attachment_image( $image, 'banner' );
        }
      ?>
    </div>
    <?php if ($heading) { ?>
      <div class="container <?php if ($captionalignment == 'Left') { echo 'caption-left'; } ?>">
        <div class="caption antialiased">
          <h1><?php echo $heading; ?></h1>
          <p><?php echo $text; ?></p>
          <?php if ($buttonlink) { ?>
            <a href="<?php echo $buttonlink; ?>" class="btn btn-primary">
              <?php if ($buttontext) { echo $buttontext; } else { echo 'View Details'; } ?>
            </a>
          <?php } ?>
        </div>
      </div>
    <?php } ?>
  </div>
  <?php
    if ($hasstatistics) {
      if( have_rows('statistics') ):
  ?>
    <section class="key-stats">
      <div class="container">
        <div class="row">
          <?php
            while ( have_rows('statistics') ) : the_row();
            $icon = get_sub_field('icon');
            $text = get_sub_field('text');
          ?>
            <div class="col-sm key-stat-wrapper">
              <div class="key-stat">
                <?php if ($icon) { ?>
                  <div class="key-stat-image">
                    <img src="<?php bloginfo('template_directory'); ?>/img/x.gif" data-src="<?php echo $icon['url']; ?>" class="lazy" alt="<?php echo $icon['alt']; ?>" />
                  </div>
                <?php } ?>
                <?php echo $text; ?>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    </section>
  <?php
      endif;
    }
  ?>
</section>
