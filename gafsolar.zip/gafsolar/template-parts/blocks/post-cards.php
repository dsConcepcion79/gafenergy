<?php

/**
 * Post Cards Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'post-cards-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'post-cards';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
$heading = get_field('heading');
$posttype = get_field('post_type');
$poststoshow = get_field('posts_to_show');
$order = get_field('order');
$columns = get_field('columns');

?>
<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?>">
  <div class="container">
    <h2><?php echo $heading; ?></h2>
    <div class="row">
      <?php
      $args = array(
      'post_type' => $posttype,
      'posts_per_page' => $poststoshow,
      'order' => $order
      );
      $the_query = new WP_Query( $args );
      if( $the_query->have_posts() ):
        $postcount=0;
      while ( $the_query->have_posts() ) : $the_query->the_post();
        $postcount++;
        $postid = get_the_ID();
        $role = get_field('role',$postid);
    ?>
    <div class="col-sm-<?php if ($columns=='2') { echo '6'; } elseif ($columns=='3') { echo '4'; } else { echo '3'; } ?>">
      <article>
        <a href="<?php the_permalink(); ?>">
          <div class="image-wrapper">
            <?php the_post_thumbnail('post-card'); ?>
          </div>
          <h3><?php the_title(); ?></h3>
          <?php /* <header class="article-meta">
            Posted <time datetime="<?php the_time('Y-m-d'); ?>"><?php the_time('F j, Y'); ?></time>
          </header> */ ?>
          <?php if ($role) { ?>
            <p><?php echo $role; ?></p>
          <?php } ?>
        </a>
      </article>
    </div>
    <?php
       /* if ($postcount %$columns == 0) {
          echo '</div><div class="row">';
        } */

      endwhile;
      endif;

      wp_reset_postdata();
    ?>
    </div>
  </div>
</section>
