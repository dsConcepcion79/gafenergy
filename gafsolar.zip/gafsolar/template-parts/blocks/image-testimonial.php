<?php

/**
 * Image Testimonial Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'image-testimonial-' . $block['id'];
if( !empty($block['anchor']) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$className = 'testimonials';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

// Load values and passing defaults.
$image = get_field('image') ?: 295;
$testimonial = get_field('testimonial') ?: 'Your testimonial here...';
$speaker = get_field('speaker');
$role = get_field('role');
?>
<section id="<?php echo esc_attr($id); ?>" class="<?php echo esc_attr($className); ?> bg-ltgrey">
  <div class="container">
    <div class="row d-flex align-items-center">
      <div class="col-md-6">
        <div class="image-wrapper">
          <?php echo wp_get_attachment_image( $image, 'testimonial' ); ?>
        </div>
      </div>
      <div class="col-md-6 text-center">
        <div class="testimonial h60 v75 m-v0-75 sm-v0-75 m-h15">
          <div class="quote">
            <?php echo $testimonial; ?>
          </div>
          <?php if ($speaker) { ?>
            <hr/>
            <div class="speaker">
              <strong><?php echo $speaker; ?></strong>
              <?php if ($role) { echo $role; } ?>
            </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>
